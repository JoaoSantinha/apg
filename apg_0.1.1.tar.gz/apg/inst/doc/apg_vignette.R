## -----------------------------------------------------------------------------
n <- 100
p <- 5
x <- matrix(rnorm(n*p),n,p)
y <- rbinom(n,1,0.5)*2-1
lambda <- 0.2*max(abs(crossprod(y,x)))/n

## -----------------------------------------------------------------------------
library(apg)
m <- glm.apg(x, y, lambda=lambda)
m

## -----------------------------------------------------------------------------
library(glmnet)
m2 <- glmnet(x, y, standardize=FALSE, lambda=lambda)
coef(m2)

## -----------------------------------------------------------------------------
# Ridge regression with intercept:
m <- glm.apg(x, y, lambda=lambda, opts=list(alpha=0))
m
# Does the same as
m2 <- glmnet(x, y, standardize=FALSE, lambda=lambda, alpha=0)
coef(m2) 
# Elastic net regression with intercept:
m <- glm.apg(x, y, lambda=lambda, opts=list(alpha=0.5))
m
# Does the same as
m2 <- glmnet(x, y, standardize=FALSE, lambda=lambda, alpha=0.5)
coef(m2)

## -----------------------------------------------------------------------------
# Elastic net regression without intercept:
m <- glm.apg(x, y, lambda=lambda, intercept=FALSE, opts=list(alpha=0.5))
m
# Does the same as
m2 <- glmnet(x, y, standardize=FALSE, lambda=lambda, alpha=0.5, intercept=FALSE)
coef(m2)

## -----------------------------------------------------------------------------
# Lasso penalized logistic regression with intercept:
m <- glm.apg(x, y, family="binomial", lambda=lambda)
m
# Does the same as
m2 <- glmnet(x, y, family="binomial", lambda=lambda, standardize=FALSE)
coef(m2)
# Elastic net penalized logistic regression with intercept:
m <- glm.apg(x, y, family="binomial", lambda=lambda, opts=list(alpha=0.5))
m
# Does the same as
m2 <- glmnet(x, y, family="binomial", lambda=lambda, standardize=FALSE, alpha=0.5)
coef(m2)

## -----------------------------------------------------------------------------
# Isotonic regression with offset
m <- glm.apg(x, y, penalty="isotonic", lambda=lambda)
m
# Isotonic logistic regression with offset
m <- glm.apg(x, y, family="binomial", penalty="isotonic", lambda=lambda)
m
mnorm <- sqrt(sum(m$b^2))
# Isotonic logistic regression with offset, with non-decreasing model of bounded norm
m <- glm.apg(x, y, family="binomial", penalty="boundednondecreasing", lambda=lambda, opts=list(maxnorm=mnorm))
m
m <- glm.apg(x, y, family="binomial", penalty="boundednondecreasing", lambda=lambda, opts=list(maxnorm=mnorm/2))
m

## -----------------------------------------------------------------------------
myprox <- function(x, ...) {
    u <- x
    u[x<0] <- 0
    return(u)
}

## -----------------------------------------------------------------------------
m <- apg(grad.logistic, myprox, p, opts=list(A=x, b=y))
m

